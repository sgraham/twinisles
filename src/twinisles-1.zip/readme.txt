Twin Isles
Scott Graham
Release 1

Twin Isles is a homebrew Civilization/SimCity/Utopia-style game for the Nintendo DS.

There's a "tip" system to teach you a little about the game, which I recommend
you leave on for the first few games you play.

There's currently only one mode of play: "Free Play". It's a open-ended mode
where the only goal is keep your people happy and grow the population. I'm
planning on various other modes including wifi multiplayer, but hey, it's the
first release.

If you have SRAM on your GBA cart you can optionally save a replay of the game
to the SRAM when you quit from the pause menu. Replays can be replayed from
the Single Player menu.

Check for new releases at http://h4ck3r.net/.

If you have feedback, or find a bug, drop me a line at the domain h4ck3r.net
with 'twinisles' before the @ sign. (sorry, stupid spam bots seem to even read
text files inside of zip files on web pages these days).
